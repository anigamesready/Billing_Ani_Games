# GitHub Actions — Build APK v11.29.1

ZIP ini sudah disiapkan agar GitHub Actions dapat membangun APK debug otomatis. File `.github/workflows/build-android-apk.yml` ada di root paket.

## Cara pakai
1. Buat atau buka repository GitHub yang akan dipakai.
2. Ekstrak **seluruh isi ZIP** ini, lalu unggah/push isinya langsung ke root repository (jangan membuat folder pembungkus `Ani-Games-Billing-Android-APK-PREBUILD-v11.29.1/`). Folder `.github` harus berada di root repository agar workflow terdeteksi.
3. Pastikan branch bernama `main` atau `master`, kemudian buka tab **Actions**. Jalankan **Build Android APK** lewat `Run workflow`, atau push commit ke branch tersebut.
4. Setelah job berhasil, buka hasil workflow dan unduh artifact `Ani-Games-Billing-Android-v11.29.1-debug-apk`. Isi artifact adalah `app-debug.apk`.

Workflow memakai JDK 17, Android SDK 35, Android Gradle Plugin 8.7.3, dan Gradle 8.9. Gradle Wrapper tidak diperlukan untuk workflow ini karena versi Gradle dipasang langsung di runner.

## Integrasi data
Asset aplikasi menunjuk langsung ke Supabase project `wzkjpycjizexxcxrfdvr` dan memakai publishable key (kunci publik). APK yang berhasil dibangun akan mengakses project/database yang sama; build tidak membuat database baru dan tidak menyalin database. Login dan hak akses tetap ditentukan oleh Supabase Auth/RPC/RLS yang sudah aktif.

## Batas penting
- Workflow menghasilkan **APK debug** yang dapat dipakai untuk pengujian; bukan APK release bertanda tangan resmi. Rilis publik perlu ditandatangani dengan keystore milik sendiri. Jangan taruh keystore/password di repository.
- Build sukses hanya membuktikan source bisa dikompilasi, bukan seluruh fungsi sudah lolos pengujian pada ponsel. Tes login, dashboard, Billing Control, CRUD rental, daftar PC, dan koneksi internet setelah memasang APK.
- Kontrol IoT Blynk belum berfungsi sampai secret `BLYNK_AUTH_TOKEN` dikonfigurasi di Supabase Edge Functions Secrets. Jangan masukkan token Blynk ke source APK.
- Data diambil dari database Supabase yang sudah ada; tidak ada migrasi/duplikasi database oleh workflow.
