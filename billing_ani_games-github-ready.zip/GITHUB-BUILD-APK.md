# Build APK lewat GitHub Actions

Workflow otomatis ada di `.github/workflows/build-apk.yml`.

1. Upload/push seluruh isi project ini ke repository GitHub `billing_ani_games` pada branch `main` (atau `master`).
2. Buka tab **Actions** di repository.
3. Pilih **Build Ani Games APK** lalu tekan **Run workflow** jika workflow belum berjalan otomatis.
4. Tunggu job selesai dengan status hijau.
5. Di bagian **Artifacts**, unduh `Ani-Games-Ready-APK-...`. Ekstrak ZIP artifact untuk memperoleh `app-debug.apk`.

APK debug ditandatangani dengan debug key yang dibuat oleh Android Gradle Plugin dan bisa dipakai untuk instalasi/pengujian. Ini bukan APK release untuk publikasi Play Store. Untuk rilis publik, siapkan signing key privat dan GitHub Actions Secrets; jangan commit keystore atau password ke repository.

## Catatan penting

- Workflow menggunakan Java 17, Android SDK 35, Android Gradle Plugin 8.7.3 dan Gradle 8.9.
- Source Android yang tersedia membungkus UI web lokal dalam Android WebView. Build yang sukses hanya membuktikan APK terkompilasi; login, billing, API Netlify, dan sinkronisasi Supabase tetap harus diuji pada perangkat.
- Jangan masukkan service-role key atau kredensial rahasia Supabase ke source atau repository. Gunakan hanya konfigurasi publik yang memang dirancang untuk client dan aturan RLS yang benar.
